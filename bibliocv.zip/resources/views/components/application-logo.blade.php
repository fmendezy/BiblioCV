<img src="{{ asset('images/logo.png') }}" alt="Logo" class="w-16 h-16">
